# NeuroConn
Software project for BIOEN 537 computational systems biology. This package generates a general spiking network model with local field potnetial readout. LFPs can be uses to fit the model to data and estimate parameters of connectivity between layers and neuronal density of layers.
